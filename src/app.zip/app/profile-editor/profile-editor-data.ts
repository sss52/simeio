export const Users = [
    { userName: "anutumma", email: 'anutumma@gmail.com', fullName: 'Anu S Tumma'},
    { userName: "bhagyatumma", email: 'bhagyatumma@gmail.com', fullName: 'Bhagya S Tumma'},
    { userName: "sanjutumma", email: 'sanjutumma@gmail.com', fullName: 'Sanjay S Tumma'}
];
